import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import WhyWorkWithMe from '@/components/WhyWorkWithMe';
import BioManifesto from '@/components/BioManifesto';
import IAJourney from '@/components/IAJourney';
import IAClub from '@/components/IAClub';
import IAPowers from '@/components/IAPowers';
import ResultsShowcase from '@/components/ResultsShowcase';
import Footer from '@/components/Footer';

export default function HomePage() {
  return (
    <main className="relative w-full bg-black">
      <Navbar />
      <Hero />
      
      <section id="servicios">
        <WhyWorkWithMe />
      </section>

      <BioManifesto />

      <section id="proceso">
        <IAJourney />
      </section>

      <IAClub />

      <section id="superpoderes">
        <IAPowers />
      </section>

      <ResultsShowcase />

      <Footer />
    </main>
  );
}