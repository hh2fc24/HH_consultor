import Link from 'next/link';
import { Linkedin, Twitter, Youtube, Mail, Phone, MapPin, Award, Users, Clock, ArrowRight, Sparkles } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="relative bg-gradient-to-b from-gray-900 via-black to-gray-900 border-t border-cyan-500/20 overflow-hidden">
      {/* Elementos decorativos de fondo */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-32 h-32 bg-cyan-500/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-40 h-40 bg-purple-500/20 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Sección superior con CTA destacado */}
        <div className="py-16 border-b border-white/10">
          <div className="text-center max-w-4xl mx-auto">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Sparkles className="w-6 h-6 text-cyan-400" />
              <span className="text-cyan-400 font-semibold">¿Listo para transformar tu negocio?</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              No esperes más. La IA ya está aquí, 
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400"> y tu competencia también la está usando</span>
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Únete a más de 50 empresas que ya transformaron su operación con nuestras soluciones de IA
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white px-8 py-4 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-cyan-500/25 flex items-center justify-center gap-2">
                Iniciar Conversación Estratégica
                <ArrowRight className="w-5 h-5" />
              </button>
              <button className="border border-cyan-500/50 hover:border-cyan-400 text-cyan-400 hover:text-white hover:bg-cyan-500/10 px-8 py-4 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center gap-2">
                Ver Casos de Éxito
                <Award className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Sección principal del footer */}
        <div className="py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            
            {/* Columna 1: Información de la empresa con personalidad */}
            <div className="lg:col-span-2">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-xl">H</span>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">Hugo Hormazábal</h3>
                  <p className="text-cyan-400 font-medium">Consultor Estratégico en IA</p>
                </div>
              </div>
              
              <p className="text-gray-300 mb-6 text-lg leading-relaxed">
                "No traduzco código. Traduzco complejidad en resultados estratégicos. 
                Mi obsesión es ayudarte a pensar mejor, decidir con claridad y liderar con impacto real."
              </p>

              {/* Credenciales destacadas */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
                <div className="bg-white/5 backdrop-blur-sm rounded-lg p-4 border border-white/10">
                  <div className="flex items-center gap-2 mb-2">
                    <Users className="w-5 h-5 text-cyan-400" />
                    <span className="text-white font-semibold">50+</span>
                  </div>
                  <p className="text-gray-400 text-sm">Proyectos IA</p>
                </div>
                <div className="bg-white/5 backdrop-blur-sm rounded-lg p-4 border border-white/10">
                  <div className="flex items-center gap-2 mb-2">
                    <Award className="w-5 h-5 text-cyan-400" />
                    <span className="text-white font-semibold">12+</span>
                  </div>
                  <p className="text-gray-400 text-sm">Años Experiencia</p>
                </div>
                <div className="bg-white/5 backdrop-blur-sm rounded-lg p-4 border border-white/10">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="w-5 h-5 text-cyan-400" />
                    <span className="text-white font-semibold">98%</span>
                  </div>
                  <p className="text-gray-400 text-sm">Satisfacción</p>
                </div>
              </div>

              {/* Redes sociales mejoradas */}
              <div>
                <p className="text-white font-semibold mb-4">Sígueme para insights diarios sobre IA</p>
                <div className="flex gap-4">
                  <a href="https://linkedin.com/in/hugohormazabal" 
                     className="group bg-white/5 hover:bg-cyan-500/20 border border-white/10 hover:border-cyan-400/50 rounded-lg p-3 transition-all duration-300">
                    <Linkedin className="w-6 h-6 text-gray-400 group-hover:text-cyan-400 transition-colors" />
                  </a>
                  <a href="#" 
                     className="group bg-white/5 hover:bg-cyan-500/20 border border-white/10 hover:border-cyan-400/50 rounded-lg p-3 transition-all duration-300">
                    <Twitter className="w-6 h-6 text-gray-400 group-hover:text-cyan-400 transition-colors" />
                  </a>
                  <a href="#" 
                     className="group bg-white/5 hover:bg-cyan-500/20 border border-white/10 hover:border-cyan-400/50 rounded-lg p-3 transition-all duration-300">
                    <Youtube className="w-6 h-6 text-gray-400 group-hover:text-cyan-400 transition-colors" />
                  </a>
                </div>
              </div>
            </div>
            
            {/* Columna 2: Servicios con iconos */}
            <div>
              <h4 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                <div className="w-2 h-2 bg-cyan-400 rounded-full"></div>
                Servicios
              </h4>
              <ul className="space-y-4">
                <li>
                  <Link href="/consultoria" className="group flex items-center gap-3 text-gray-400 hover:text-cyan-400 transition-colors">
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    Consultoría Estratégica
                  </Link>
                </li>
                <li>
                  <Link href="/implementacion" className="group flex items-center gap-3 text-gray-400 hover:text-cyan-400 transition-colors">
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    Implementación de IA
                  </Link>
                </li>
                <li>
                  <Link href="/capacitacion" className="group flex items-center gap-3 text-gray-400 hover:text-cyan-400 transition-colors">
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    Capacitación Corporativa
                  </Link>
                </li>
                <li>
                  <Link href="/desarrollo" className="group flex items-center gap-3 text-gray-400 hover:text-cyan-400 transition-colors">
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    Desarrollo Personalizado
                  </Link>
                </li>
                <li>
                  <Link href="/club" className="group flex items-center gap-3 text-cyan-400 hover:text-white transition-colors font-semibold">
                    <Sparkles className="w-4 h-4 group-hover:rotate-12 transition-transform" />
                    Altius Ignite Club
                  </Link>
                </li>
              </ul>
            </div>
            
            {/* Columna 3: Contacto mejorado */}
            <div>
              <h4 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                Contacto Directo
              </h4>
              
              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center">
                    <Mail className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div>
                    <p className="text-white font-medium">hugo@altiusignite.com</p>
                    <p className="text-gray-400 text-sm">Respuesta en 24h</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center">
                    <Phone className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div>
                    <p className="text-white font-medium">+56 9 XXXX XXXX</p>
                    <p className="text-gray-400 text-sm">WhatsApp disponible</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center">
                    <MapPin className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div>
                    <p className="text-white font-medium">Santiago, Chile</p>
                    <p className="text-gray-400 text-sm">Consultoría global</p>
                  </div>
                </div>
              </div>

              {/* Newsletter mejorado */}
              <div className="bg-gradient-to-r from-cyan-500/10 to-purple-500/10 backdrop-blur-sm rounded-xl p-6 border border-white/10">
                <h5 className="text-white font-bold mb-2 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  IA Weekly Insights
                </h5>
                <p className="text-gray-300 text-sm mb-4">
                  Estrategias prácticas de IA cada martes en tu inbox
                </p>
                <div className="flex flex-col gap-2">
                  <input 
                    type="email" 
                    placeholder="tu@email.com" 
                    className="bg-black/30 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 w-full focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-400"
                  />
                  <button className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white px-4 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105">
                    Suscribirme Gratis
                  </button>
                </div>
                <p className="text-gray-400 text-xs mt-2">
                  +2,500 profesionales ya suscritos
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Sección de clientes destacados */}
        <div className="py-12 border-t border-white/10">
          <div className="text-center mb-8">
            <p className="text-gray-400 mb-4">Empresas que confían en nuestras soluciones</p>
            <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
              <div className="text-white font-bold text-lg">Cencosud</div>
              <div className="text-white font-bold text-lg">Scotiabank</div>
              <div className="text-white font-bold text-lg">SONDA</div>
              <div className="text-white font-bold text-lg">BancoEstado</div>
              <div className="text-white font-bold text-lg">MetLife</div>
              <div className="text-white font-bold text-lg">Tenpo</div>
            </div>
          </div>
        </div>

        {/* Footer bottom mejorado */}
        <div className="border-t border-white/10 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-4">
              <p className="text-gray-500 text-sm">
                © {new Date().getFullYear()} Hugo Hormazábal - Altius Ignite. Todos los derechos reservados.
              </p>
              <div className="hidden md:flex items-center gap-2 text-gray-500 text-sm">
                <span>•</span>
                <span>Hecho con IA y propósito</span>
              </div>
            </div>
            <div className="flex gap-6">
              <Link href="/terminos" className="text-gray-500 hover:text-gray-300 text-sm transition-colors">
                Términos
              </Link>
              <Link href="/privacidad" className="text-gray-500 hover:text-gray-300 text-sm transition-colors">
                Privacidad
              </Link>
              <Link href="/cookies" className="text-gray-500 hover:text-gray-300 text-sm transition-colors">
                Cookies
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;